import SwiftUI

@main
struct HomeviewApp: App {
    @State private var config: HouseConfig?

    var body: some Scene {
        WindowGroup {
            RootView(config: $config)
                .onOpenURL { url in
                    if let c = HouseConfig(url: url) { config = c }
                }
                .onContinueUserActivity(NSUserActivityTypeBrowsingWeb) { activity in
                    if let url = activity.webpageURL, let c = HouseConfig(url: url) { config = c }
                }
        }
    }
}
