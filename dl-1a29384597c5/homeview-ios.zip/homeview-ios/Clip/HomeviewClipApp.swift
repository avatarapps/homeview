import SwiftUI

/// App Clip: opened from the configurator link, shows that exact house at once, no install.
@main
struct HomeviewClipApp: App {
    @State private var config: HouseConfig?

    var body: some Scene {
        WindowGroup {
            RootView(config: $config)
                .onContinueUserActivity(NSUserActivityTypeBrowsingWeb) { activity in
                    if let url = activity.webpageURL, let c = HouseConfig(url: url) { config = c }
                }
        }
    }
}
