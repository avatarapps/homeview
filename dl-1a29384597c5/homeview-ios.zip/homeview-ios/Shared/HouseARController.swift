import ARKit
import Combine
import Metal
import RealityKit
import UIKit

/// Places a 1:1 house on the ground and lets the user move it anywhere:
/// - the house appears at once, on an estimated ground, and settles when ARKit finds the real ground;
/// - one finger drags it along an endless ground plane (no limit to the detected patch);
/// - two fingers turn it around its own centre;
/// - buttons nudge it in small steps relative to where the phone points.
/// The house is never scaled.
final class HouseARController: NSObject, ObservableObject, ARSessionDelegate {
    @Published var loading = true
    @Published var errorText: String?
    @Published var groundFound = false
    @Published var placed = false
    @Published var locked = false
    @Published var distanceText = ""

    let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: false)
    let config: HouseConfig

    private let anchor = AnchorEntity(world: .zero)
    private let pivot = Entity()                 // at the centre of the footprint, on the ground
    private var depth: Float = 10                // footprint along the house's front-to-back axis
    private var groundY: Float?
    private var bestPlaneArea: Float = 0
    private var trackingSince: Date?
    private var dragOffset: SIMD3<Float>?
    private var turnStart: simd_quatf?
    private var updateSub: (any Combine.Cancellable)?
    private var textures: [String: MaterialParameters.Texture] = [:]

    init(config: HouseConfig) {
        self.config = config
        super.init()
        arView.session.delegate = self
        arView.renderOptions.insert(.disableMotionBlur)
        arView.scene.addAnchor(anchor)
        anchor.addChild(pivot)
        pivot.isEnabled = false

        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.maximumNumberOfTouches = 1
        let turn = UIRotationGestureRecognizer(target: self, action: #selector(onTurn(_:)))
        arView.addGestureRecognizer(pan)
        arView.addGestureRecognizer(turn)

        updateSub = arView.scene.subscribe(to: SceneEvents.Update.self) { [weak self] _ in self?.tick() }
        Task { await load() }
    }

    func start() {
        let cfg = ARWorldTrackingConfiguration()
        cfg.planeDetection = [.horizontal]
        cfg.environmentTexturing = .automatic
        arView.session.run(cfg, options: [.resetTracking, .removeExistingAnchors])
    }

    func stop() { arView.session.pause() }

    // MARK: - Loading

    private func download(_ url: URL, ext: String) async throws -> URL {
        let (tmp, response) = try await URLSession.shared.download(from: url)
        if let http = response as? HTTPURLResponse, http.statusCode != 200 {
            throw URLError(.badServerResponse)
        }
        let dest = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }

    private func loadTexture(_ name: String, normal: Bool) async -> MaterialParameters.Texture? {
        if let t = textures[name] { return t }
        guard let file = try? await download(config.textureBase.appendingPathComponent(name + ".png"), ext: "png") else { return nil }
        let options = TextureResource.CreateOptions(semantic: normal ? .normal : .color)
        guard let res = try? TextureResource.load(contentsOf: file, withName: name, options: options) else { return nil }
        var tex = MaterialParameters.Texture(res)
        let d = MTLSamplerDescriptor()
        d.sAddressMode = .repeat; d.tAddressMode = .repeat
        d.minFilter = .linear; d.magFilter = .linear; d.mipFilter = .linear
        d.maxAnisotropy = 8
        tex.sampler = MaterialParameters.Texture.Sampler(d)
        textures[name] = tex
        return tex
    }

    @MainActor
    private func load() async {
        do {
            let file = try await download(config.modelURL, ext: "usdz")
            for style in config.styles.values {
                if let t = style.texture {
                    _ = await loadTexture(t, normal: false)
                    _ = await loadTexture(t + "_n", normal: true)
                }
            }
            let house = try Entity.load(contentsOf: file)
            restyle(house)
            if #available(iOS 18.0, *) { addShadows(house) }

            // put the pivot at the centre of the footprint, house resting on the ground
            let b = house.visualBounds(relativeTo: nil)
            house.position = SIMD3<Float>(-b.center.x, -b.min.y, -b.center.z)
            depth = b.extents.z
            pivot.addChild(house)
            loading = false
        } catch {
            loading = false
            errorText = "Maja laadimine ebaõnnestus. Kontrolli internetiühendust ja proovi uuesti."
        }
    }

    // MARK: - Materials from the link

    private func partName(_ e: Entity) -> String? {
        var node: Entity? = e
        for _ in 0..<3 {
            if let n = node?.name, HouseConfig.parts.contains(n) { return n }
            node = node?.parent
        }
        return nil
    }

    private func restyle(_ e: Entity) {
        if let part = partName(e), let style = config.styles[part], var model = e.components[ModelComponent.self] {
            model.materials = model.materials.map { material(from: $0, style: style) }
            e.components.set(model)
        }
        for child in e.children { restyle(child) }
    }

    private func material(from original: RealityKit.Material, style: SurfaceStyle) -> RealityKit.Material {
        var m = (original as? PhysicallyBasedMaterial) ?? PhysicallyBasedMaterial()
        if let name = style.texture, let tex = textures[name] {
            m.baseColor = PhysicallyBasedMaterial.BaseColor(tint: style.color, texture: tex)
            if let n = textures[name + "_n"] { m.normal = PhysicallyBasedMaterial.Normal(texture: n) }
        } else {
            m.baseColor = PhysicallyBasedMaterial.BaseColor(tint: style.color, texture: m.baseColor.texture)
        }
        if let r = style.roughness { m.roughness = PhysicallyBasedMaterial.Roughness(floatLiteral: r) }
        if let mt = style.metallic { m.metallic = PhysicallyBasedMaterial.Metallic(floatLiteral: mt) }
        return m
    }

    @available(iOS 18.0, *)
    private func addShadows(_ e: Entity) {
        if e.components.has(ModelComponent.self) {
            e.components.set(GroundingShadowComponent(castsShadow: true))
        }
        for child in e.children { addShadows(child) }
    }

    // MARK: - Ground

    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) { updateGround(anchors) }
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) { updateGround(anchors) }

    private func updateGround(_ anchors: [ARAnchor]) {
        guard let camY = arView.session.currentFrame?.camera.transform.columns.3.y else { return }
        for case let plane as ARPlaneAnchor in anchors where plane.alignment == .horizontal {
            let y = plane.transform.columns.3.y
            let area = plane.planeExtent.width * plane.planeExtent.height
            // the ground is well below the phone; take the biggest such surface
            guard y < camY - 0.6, area > bestPlaneArea else { continue }
            bestPlaneArea = area
            groundY = y
            if !groundFound { groundFound = true }
            if placed { pivot.position.y = y }
        }
    }

    // MARK: - Per frame

    private func tick() {
        guard let frame = arView.session.currentFrame else { return }
        if case .normal = frame.camera.trackingState {
            if trackingSince == nil { trackingSince = Date() }
        }
        if !placed, !loading, errorText == nil, let since = trackingSince {
            if groundY == nil, let hit = arView.raycast(from: CGPoint(x: arView.bounds.midX, y: arView.bounds.midY), allowing: .estimatedPlane, alignment: .horizontal).first {
                let y = hit.worldTransform.columns.3.y
                if y < frame.camera.transform.columns.3.y - 0.6 { groundY = y }
            }
            // no surface yet: assume the ground about 1.45 m below the phone, refine later
            if groundY == nil, Date().timeIntervalSince(since) > 1.2 {
                groundY = frame.camera.transform.columns.3.y - 1.45
            }
            if groundY != nil { placeInFront(distance: config.frontDistance) }
        }
        if placed { updateDistance() }
    }

    private func flatForward() -> (pos: SIMD3<Float>, fwd: SIMD3<Float>, right: SIMD3<Float>) {
        let m = arView.cameraTransform.matrix
        let pos = SIMD3<Float>(m.columns.3.x, m.columns.3.y, m.columns.3.z)
        var fwd = -SIMD3<Float>(m.columns.2.x, 0, m.columns.2.z)
        if simd_length(fwd) < 1e-3 { fwd = SIMD3<Float>(0, 0, -1) }
        fwd = simd_normalize(fwd)
        let right = SIMD3<Float>(-fwd.z, 0, fwd.x)
        return (pos, fwd, right)
    }

    /// Front edge `distance` metres in front of the phone, front facing the phone.
    func placeInFront(distance: Float) {
        guard let gy = groundY else { return }
        let (pos, fwd, _) = flatForward()
        let c = pos + fwd * (distance + depth / 2)
        pivot.position = SIMD3<Float>(c.x, gy, c.z)
        pivot.orientation = simd_quatf(angle: atan2(-fwd.x, -fwd.z), axis: SIMD3<Float>(0, 1, 0))
        pivot.isEnabled = true
        placed = true
    }

    private func updateDistance() {
        let (pos, _, _) = flatForward()
        let front = pivot.position + pivot.orientation.act(SIMD3<Float>(0, 0, depth / 2))
        let d = simd_length(SIMD2<Float>(front.x - pos.x, front.z - pos.z))
        let text = String(format: "%.1f m", d).replacingOccurrences(of: ".", with: ",")
        if text != distanceText { distanceText = text }
    }

    // MARK: - Gestures and buttons

    private func groundPoint(_ p: CGPoint) -> SIMD3<Float>? {
        guard let gy = groundY, let ray = arView.ray(through: p) else { return nil }
        guard ray.direction.y < -1e-3 else { return nil }          // finger above the horizon
        let t = min((gy - ray.origin.y) / ray.direction.y, 400)
        return ray.origin + ray.direction * t
    }

    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        guard placed, !locked else { return }
        let p = g.location(in: arView)
        switch g.state {
        case .began:
            if let hit = groundPoint(p) { dragOffset = pivot.position - hit }
        case .changed:
            if let off = dragOffset, let hit = groundPoint(p) {
                let n = hit + off
                pivot.position = SIMD3<Float>(n.x, pivot.position.y, n.z)
            }
        default:
            dragOffset = nil
        }
    }

    @objc private func onTurn(_ g: UIRotationGestureRecognizer) {
        guard placed, !locked else { return }
        switch g.state {
        case .began:
            turnStart = pivot.orientation
        case .changed:
            if let s = turnStart {
                pivot.orientation = simd_quatf(angle: -Float(g.rotation), axis: SIMD3<Float>(0, 1, 0)) * s
            }
        default:
            turnStart = nil
        }
    }

    /// Move along the ground relative to the phone: forward = away from the user.
    func nudge(forward: Float, right: Float) {
        guard placed, !locked else { return }
        let (_, fwd, r) = flatForward()
        pivot.position += fwd * forward + r * right
    }

    func turn(degrees: Float) {
        guard placed, !locked else { return }
        pivot.orientation = simd_quatf(angle: degrees * .pi / 180, axis: SIMD3<Float>(0, 1, 0)) * pivot.orientation
    }

    func bringBack() {
        guard !locked else { return }
        placeInFront(distance: config.frontDistance)
    }
}
