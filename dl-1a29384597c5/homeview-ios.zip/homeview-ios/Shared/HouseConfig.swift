import Foundation
import UIKit

/// Colour and material of one tintable part of the house (wall, roof, deck, frame, fascia, door, garage).
struct SurfaceStyle {
    var color: UIColor
    var texture: String?      // greyscale detail texture name on the server, e.g. "boards_v" (normal map: "<name>_n")
    var roughness: Float?
    var metallic: Float?
}

/// Everything the AR view needs, read from the link the configurator page opens:
/// https://homeview.secondsun.ee/ar?n=Teder%20224&m=<usdz url>&t=<texture folder url>&d=10
///     &wall=2C3243&wallTex=boards_v&roof=2B313C&roofTex=shingle&roofR=0.85&roofM=0
///     &deck=C79F76&deckTex=deck&frame=F2F0EA&fascia=F2F0EA&door=8A6A4C&garage=2C3243
struct HouseConfig: Equatable {
    var title: String
    var modelURL: URL
    var textureBase: URL
    var styles: [String: SurfaceStyle]
    var frontDistance: Float
    var sourceURL: String

    static func == (a: HouseConfig, b: HouseConfig) -> Bool { a.sourceURL == b.sourceURL }

    /// Hosts the app accepts models and textures from.
    static let allowedHosts: Set<String> = ["homeview.secondsun.ee", "avatarapps.github.io"]
    static let parts = ["wall", "roof", "deck", "frame", "fascia", "door", "garage"]

    /// Our own demo house, shown when the app is opened without a link.
    static let demo = HouseConfig(
        title: "Metsamaja",
        modelURL: URL(string: "https://avatarapps.github.io/homeview/demo/app/metsamaja137_c0_p0_m1.usdz")!,
        textureBase: URL(string: "https://avatarapps.github.io/homeview/demo/tex/")!,
        styles: [:], frontDistance: 10, sourceURL: "demo")

    init(title: String, modelURL: URL, textureBase: URL, styles: [String: SurfaceStyle],
         frontDistance: Float, sourceURL: String) {
        self.title = title; self.modelURL = modelURL; self.textureBase = textureBase
        self.styles = styles; self.frontDistance = frontDistance; self.sourceURL = sourceURL
    }

    init?(url: URL) {
        guard let comps = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        var q: [String: String] = [:]
        for item in comps.queryItems ?? [] { if let v = item.value { q[item.name] = v } }

        guard let m = q["m"], let mURL = URL(string: m), let mHost = mURL.host,
              mURL.scheme == "https", Self.allowedHosts.contains(mHost) else { return nil }
        var tURL = mURL.deletingLastPathComponent().deletingLastPathComponent().appendingPathComponent("tex/")
        if let t = q["t"], let u = URL(string: t), u.scheme == "https", let h = u.host, Self.allowedHosts.contains(h) {
            tURL = u
        }

        var styles: [String: SurfaceStyle] = [:]
        for part in Self.parts {
            guard let hex = q[part], let color = UIColor(hex: hex) else { continue }
            styles[part] = SurfaceStyle(color: color,
                                        texture: q[part + "Tex"].flatMap { Self.safeName($0) },
                                        roughness: q[part + "R"].flatMap { Float($0) },
                                        metallic: q[part + "M"].flatMap { Float($0) })
        }
        self.init(title: q["n"] ?? "Maja",
                  modelURL: mURL, textureBase: tURL, styles: styles,
                  frontDistance: min(max(q["d"].flatMap { Float($0) } ?? 10, 2), 80),
                  sourceURL: url.absoluteString)
    }

    /// Texture names come from the link: allow only plain file names.
    private static func safeName(_ s: String) -> String? {
        s.range(of: "^[a-z0-9_]{1,40}$", options: .regularExpression) != nil ? s : nil
    }
}

extension UIColor {
    convenience init?(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        guard s.count == 6, let v = UInt32(s, radix: 16) else { return nil }
        self.init(red: CGFloat((v >> 16) & 0xFF) / 255,
                  green: CGFloat((v >> 8) & 0xFF) / 255,
                  blue: CGFloat(v & 0xFF) / 255, alpha: 1)
    }
}
